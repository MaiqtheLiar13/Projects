<?php

$conexion = mysqli_connect('localhost', 'root', 'MalaMedicina5', 'db_pagweb');
if(!$conexion){
    echo ('Error en la conexión de la base de datos');
    exit;
}

echo('Exito en la conexión con la base de datos')

?>