<?php

include_once(conexión.php)

    $nombres = $_POST['nombres'];
    $celular = $_POST['celular'];
    $email = $_POST['email'];
    $mensaje = $_POST['mensaje'];

    $insert = "INSERT INTO tb_clientes (nombres, celular, email, mensaje) VALUES ('$nombres', '$celular', '$email', '$mensaje')";
    $resultado = mysqli_query($conexion, $insert);


    if (!resultado) {
        echo <script> alert ("Error en el registro").window.location = 'contacto.html' </script>
    }
    else {
        echo <script> alert ("Datos registrados correctamente").window.location = 'contacto.html' </script>
    }

    mysqli_close($conexion);

?>